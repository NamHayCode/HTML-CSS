const image = document.getElementById('validationDefault01'),
    title = document.getElementById('validationDefault02'),
    topic = document.getElementById('validationDefault03');

function upload() {
    if (sessionStorage.getItem('user')) {
        let currentDate = new Date(),
            user = JSON.parse(sessionStorage.getItem('user')),
            imageInfor = image.files[0];

        convertImage(imageInfor)
            .then(imagePath => {
                var data = {
                    id: imagesData.length > 0 ? imagesData[imagesData.length - 1].id + 1 : 1,
                    image: imagePath,
                    topic: topic.value,
                    upload: new Date(currentDate),
                    download: 0,
                    like: 0,
                    comment: 0,
                    view: 0,
                    userID: user.id,
                    title: title.value
                }
                imagesData.push(data);
                save();
            })
            .catch(error => {
                console.error('Error converting image to base64:', error);
            });
    }
    else {
        window.location.href = 'moodpix.html';
        alert('Please login again');
    }
}

function convertImage(img) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
        reader.readAsDataURL(img);
    });
}

function save() {
    let data = imagesData.map(image => ({
        ...image,
        upload: image.upload.toISOString()
    }));
    localStorage.setItem('imagesData', JSON.stringify(data));
}
