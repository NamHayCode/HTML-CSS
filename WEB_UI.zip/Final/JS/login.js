const inputUsername = document.querySelector(".input-login-username");
const inputPassword = document.querySelector(".input-login-password");
const btnLogin = document.querySelector(".login__signInButton");

// validation form login

btnLogin.addEventListener("click", (e) => {
  e.preventDefault();
  if (inputUsername.value === "" || inputPassword.value === "") {
    alert("vui lòng không để trống");
  } else {
    const user = JSON.parse(localStorage.getItem(inputUsername.value));
    if (
      user.username === inputUsername.value &&
      user.password === inputPassword.value
    ) {
      alert("Đăng Nhập Thành Công");
      let temp = {
        id: 1,
        username: user.username
      }
      sessionStorage.setItem('user', JSON.stringify(temp));
      window.location.href = "home.html";
    } else {
      alert("Đăng Nhập Thất Bại");
    }
  }
});

var memory = [];
var a404Elements = document.getElementsByClassName("a404");

for (var i = 0; i < a404Elements.length; i++) {
  memory.push(a404Elements[i]);
}
if (memory.length > 0) {
  for (var i = 0; i < memory.length; i++) {
    memory[i].addEventListener("click", function (e) {
      window.location.href = "404.html";
    });
  }
}

var loginElements = document.getElementsByClassName("login");

loginElements[0].addEventListener("click", function (e) {
  window.location.href = "register.html";
});

