// Load and save data

function load(x) {
    switch (x) {
        case 1: {
            if (localStorage.getItem('account')) {
                account = JSON.parse(localStorage.getItem('account'));
            }
            break;
        }
        case 2: {
            if (localStorage.getItem('imagesData')) {
                imagesData = JSON.parse(localStorage.getItem('imagesData'));
                imagesData = imagesData.map(image => ({
                    ...image,
                    upload: new Date(image.upload)
                }));
            }
            break;
        }
    } 
}

// sidebar switch

const sidebar = document.querySelector('.sidebar'),
        toggle = document.getElementById('sidebar-list'),
        background = document.querySelector('.sidebar-container');

toggle.addEventListener("click", () => {
    sidebar.classList.toggle('close');
    if (background.style.background == '') {
        background.style.background = 'var(--color-black-8)';
        background.style.pointerEvents = 'auto';
    }
    else {
        background.style.background = '';
        background.style.pointerEvents = 'none'
    }
})

// Setting droplist

const setting = document.querySelector('.setting'),
    navList = document.getElementById('nav'),
    logout = document.getElementById('log-out');

setting.addEventListener('click', () => {
    if (navList.style.display == 'block') {
        navList.style.display = 'none';
    }
    else {
        navList.style.display = 'block';
    }
});

logout.addEventListener('click', () => {
    window.location.href = 'moodpix.html';
    sessionStorage.removeItem('user');
});

// Submit page

document.getElementById('submit').addEventListener('click', () => {
    window.location.href = 'upload.html';
});