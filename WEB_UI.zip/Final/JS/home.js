// popular and daily image load

var html = '';

function addImageToContainer(imageUrl, className) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.src = imageUrl;
        image.addEventListener('load', function () {
            html += `<img class="${className}" src="${image.src}" alt="Image">`;
            resolve();
        });
        image.addEventListener('error', function () {
            reject();
        });
    });
}

window.addEventListener('load', async () => {
    try {
        let temp = imagesData.slice().sort((a, b) => b.view - a.view);
        for (let i = 0; i < 10; i++) {
            await addImageToContainer(temp[i].image, "popular-image");
        }
        images[0].innerHTML = html;
        html = '';
    } catch (e) {
        console.log("Error popular image load!");
    }
    try {
        for (let i = imagesData.length - 1; i > imagesData.length - 11; i--) {
            await addImageToContainer(imagesData[i].image, "daily-image");
        }
        images[1].innerHTML = html;
        html = '';
    }
    catch (e) {
        console.log("Error daily image load!");
    }
    getValue();
});

// popular and daily image switch

const container = document.getElementsByClassName('image-switch-parent'),
    images = document.getElementsByClassName('image-switch-child'),
    image = document.getElementsByClassName('popular-image');
var currentPage = [1, 1],
    translateValue = [0, 0];

function getValue() {
    imagesWidth = images[0].clientWidth;
    imageSize = image[0].clientWidth;
    containerWidth = container[0].clientWidth;
    gap = parseInt(window.getComputedStyle(images[0]).columnGap);
    imagePerPage = Math.floor(containerWidth / (imageSize + gap));
    imagePages = Math.ceil(images[0].childElementCount / imagePerPage);
}

function switchLeft(x) {
    if (currentPage[x] == 1) {
        translateValue[x] = imagesWidth - containerWidth;
        currentPage[x] = imagePages;
    }
    else {
        if (currentPage[x] == 2) {
            translateValue[x] = 0;
            currentPage[x] = 1;
        }
        else {
            translateValue[x] = translateValue[x] - ((imageSize + gap) * imagePerPage - gap);
            currentPage[x]--;
        }
    }
    images[x].style.transform = `translateX(${-translateValue[x]}px)`;
}

function switchRight(x) {
    if (currentPage[x] == imagePages) {
        translateValue[x] = 0;
        currentPage[x] = 1;
    }
    else {
        if (currentPage[x] == (imagePages - 1)) {
            translateValue[x] = imagesWidth - containerWidth;
            currentPage[x] = imagePages;
        }
        else {
            translateValue[x] = translateValue[x] + ((imageSize + gap) * imagePerPage - gap)
            currentPage[x]++;
        }
    }
    images[x].style.transform = `translateX(${-translateValue[x]}px)`;
}

//all image load

const con = document.getElementsByClassName('all-image-group'),
    rowHeight = 250;
var imageHtml = '',
    imgArray = [];

function loadImage(image) {
    return new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = reject;
    });
}

function addImage(imgData) {
    let username = '';
    for (const x of account) {
        if (x.id == imgData.userID) {
            username = x.username;
        }
    }
    imageHtml += `<div class="image-container">
                    <div class="image-id" style="display: none;">${imgData.id}</div>
                    <img class="image" src="${imgData.image}" alt="Image">
                    <div class="image-hover">
                        <div class="image-hover-content">
                            <div class="image-hover-content-top">
                                <b class="image-title">${imgData.title}</b>
                                <div class="star-group">
                                    <p class="number">${imgData.like}</p>
                                    <img class="star-icon" src="../IMG/star-icon.svg">
                                </div>
                            </div>
                            <div class="image-hover-content-bottom">
                                <div class="user-infor">
                                    <div class="avatar"></div>
                                    <p class="username">${username}</p>
                                </div>
                                <div class="comment-group">
                                    <p class="number">${imgData.comment}</p>
                                    <img class="comment-icon" src="../IMG/comment-icon.svg">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`
}

async function createImageRows(data, rowHeight) {
    let conWidth = con[0].clientWidth;
    let currentRowWidth = 0;
    let rowIndex = 0;

    for (const element of data) {
        try {
            const image = new Image();
            image.src = element.image;
            await loadImage(image);
            imgArray.push(image);
            const ratio = image.naturalWidth / image.naturalHeight;
            const imageWidth = Math.floor(rowHeight * ratio);
            if (currentRowWidth + imageWidth <= conWidth) {
                addImage(element);
                currentRowWidth += imageWidth;
            }
            else {
                imageHtml = `<div class="image-row">${imageHtml}</div>`;
                if (rowIndex < 3) {
                    con[0].innerHTML += imageHtml;
                    rowIndex++;
                }
                else {
                    con[1].innerHTML += imageHtml;
                }
                imageHtml = '';
                addImage(element);
                currentRowWidth = imageWidth;
            }
        } catch (e) {
            console.log("Error image load!");
        }
    }
    if (imageHtml != '') {
        imageHtml = `<div class="image-row">${imageHtml}</div>`;
        if (rowIndex < 3) {
            con[0].innerHTML += imageHtml;
        }
        else {
            con[1].innerHTML += imageHtml;
        }
    }
}

window.addEventListener('load', () => {
    createImageRows(imagesData, rowHeight)
});

window.addEventListener('resize', () => {
    // 1
    containerWidth = container[0].clientWidth;
    imagePerPage = Math.floor(containerWidth / (imageSize + gap));
    imagePages = Math.ceil(images[0].childElementCount / imagePerPage);
    for (let i = 0; i < currentPage.length; i++) {
        currentPage[i] = Math.floor(translateValue[i] / ((imageSize + gap) * imagePerPage - gap)) + 1;
    }

    // 2
    let conWidth = con[0].clientWidth;
    let currentRowWidth = 0;
    let rowIndex = 0;
    con[0].innerHTML = '';
    con[1].innerHTML = '';
    imageHtml = '';

    for (let i = 0; i < imagesData.length; i++) {
        const image = imgArray[i];
        const ratio = image.naturalWidth / image.naturalHeight;
        const imageWidth = Math.floor(rowHeight * ratio);
        if (currentRowWidth + imageWidth <= conWidth) {
            addImage(imagesData[i]);
            currentRowWidth += imageWidth;
        }
        else {
            imageHtml = `<div class="image-row">${imageHtml}</div>`;
            if (rowIndex < 3) {
                con[0].innerHTML += imageHtml;
                rowIndex++;
            }
            else {
                con[1].innerHTML += imageHtml;
            }
            imageHtml = '';
            addImage(imagesData[i]);
            currentRowWidth = imageWidth;
        }
    }
    if (imageHtml != '') {
        imageHtml = `<div class="image-row">${imageHtml}</div>`;
        if (rowIndex < 3) {
            con[0].innerHTML += imageHtml;
        }
        else {
            con[1].innerHTML += imageHtml;
        }
    }
});

// Go to photography topic

const photoTopic = document.querySelector('.photo-topic');

photoTopic.addEventListener('click', () => {
    window.location.href = 'photography.html';
});