//all image load

const con = document.getElementsByClassName('all-image-group'),
    rowHeight = 250;
var imageHtml = '',
    imgArray = [];

function loadImage(image) {
    return new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = reject;
    });
}

function addImage(imgData) {
    let username = '';
    for (const x of account) {
        if (x.id == imgData.userID) {
            username = x.username;
        }
    }
    imageHtml += `<div class="image-container">
                    <div class="image-id" style="display: none;">${imgData.id}</div>
                    <img class="image" src="${imgData.image}" alt="Image">
                    <div class="image-hover">
                        <div class="image-hover-content">
                            <div class="image-hover-content-top">
                                <b class="image-title">${imgData.title}</b>
                                <div class="star-group">
                                    <p class="number">${imgData.like}</p>
                                    <img class="star-icon" src="../IMG/star-icon.svg">
                                </div>
                            </div>
                            <div class="image-hover-content-bottom">
                                <div class="user-infor">
                                    <div class="avatar"></div>
                                    <p class="username">${username}</p>
                                </div>
                                <div class="comment-group">
                                    <p class="number">${imgData.comment}</p>
                                    <img class="comment-icon" src="../IMG/comment-icon.svg">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`
}

async function createImageRows(data, rowHeight) {
    let conWidth = con[0].clientWidth;
    let currentRowWidth = 0;

    for (const element of data) {
        try {
            if (element.topic == "Photography") {
                const image = new Image();
                image.src = element.image;
                await loadImage(image);
                imgArray.push(image);
                const ratio = image.naturalWidth / image.naturalHeight;
                const imageWidth = Math.floor(rowHeight * ratio);
                if (currentRowWidth + imageWidth <= conWidth) {
                    addImage(element);
                    currentRowWidth += imageWidth;
                }
                else {
                    imageHtml = `<div class="image-row">${imageHtml}</div>`;
                    con[0].innerHTML += imageHtml;
                    imageHtml = '';
                    addImage(element);
                    currentRowWidth = imageWidth;
                }
            }
        } catch (e) {
            console.log("Error image load!");
        }
    }
    if (imageHtml != '') {
        imageHtml = `<div class="image-row">${imageHtml}</div>`;
        con[0].innerHTML += imageHtml;
    }
}

window.addEventListener('load', () => {
    createImageRows(imagesData, rowHeight)
});

window.addEventListener('resize', () => {
    let conWidth = con[0].clientWidth;
    let currentRowWidth = 0;
    con[0].innerHTML = '';
    imageHtml = '';

    for (let i = 0; i < imagesData.length; i++) {
        if (imagesData[i].topic == "Photography") {
            const image = imgArray[i];
            const ratio = image.naturalWidth / image.naturalHeight;
            const imageWidth = Math.floor(rowHeight * ratio);
            if (currentRowWidth + imageWidth <= conWidth) {
                addImage(imagesData[i]);
                currentRowWidth += imageWidth;
            }
            else {
                imageHtml = `<div class="image-row">${imageHtml}</div>`;
                con[0].innerHTML += imageHtml;
                imageHtml = '';
                addImage(imagesData[i]);
                currentRowWidth = imageWidth;
            }
        }
    }
    if (imageHtml != '') {
        imageHtml = `<div class="image-row">${imageHtml}</div>`;
        con[0].innerHTML += imageHtml;
    }
});